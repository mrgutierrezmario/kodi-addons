# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file source_utils.py
* @package script.module.thecrew
*
* @copyright (c) 2025, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import base64
import hashlib
import re
import xbmc

import six



from urllib.parse import urlparse, unquote, quote_plus

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import directstream
from resources.lib.modules import trakt
from resources.lib.modules import pyaes
from resources.lib.modules import log_utils
from resources.lib.modules.crewruntime import c

RES_4K = [' 4k', ' hd4k', ' 4khd', ' uhd', ' ultrahd', ' ultra hd', ' 2160', ' 2160p', ' hd2160', ' 2160hd']
RES_1080 = [' 1080', ' 1080p', ' 1080i', ' hd1080', ' 1080hd', ' m1080p', ' fullhd', ' full hd', ' 1o8o', ' 1o8op']
RES_720 = [' 720', ' 720p', ' 720i', ' hd720', ' 720hd', ' 72o', ' 72op']
RES_SD = [' 576', ' 576p', ' 576i', ' sd576', ' 576sd', ' 480', ' 480p', ' 480i', ' sd480', ' 480sd', ' 360', ' 360p', ' 360i', ' sd360', ' 360sd', ' 240', ' 240p', ' 240i', ' sd240', ' 240sd']
SCR = [' scr', ' screener', ' dvdscr', ' dvd scr', ' r5', ' r6']
CAM = [' camrip', ' tsrip', ' hdcam', ' hd cam', ' cam rip', ' hdts', ' dvdcam', ' dvdts', ' cam', ' telesync', ' ts']

def supported_video_extensions():
    supported_extensions = xbmc.getSupportedMedia('video').split('|')
    return [i for i in supported_extensions if i != '' and i != '.zip']

def get_qual(term):
    if any(i in term for i in RES_4K):
        return '4k'
    elif any(i in term for i in RES_1080):
        return '1080p'
    elif (any(i in term for i in RES_720) and not any(i in term for i in CAM)):
        return '720p'
    elif any(i in term for i in RES_SD):
        return 'sd'
    elif any(i in term for i in SCR):
        return 'scr'
    elif any(i in term for i in CAM):
        return 'cam'

def is_anime(content, type, type_id):
    try:
        r = trakt.getGenre(content, type, type_id)
        return 'anime' in r or 'animation' in r
    except:
        return False

def get_release_quality(release_name, release_link=None):

    #cm - def always need 2 return values and not NONE returned
    if release_name is None:
        return 'sd', []

    try:
        quality = None

        release_name = cleantitle.get_title(release_name)
        quality = get_qual(release_name)

        if not quality:
            if release_link:
                release_link = cleantitle.get_title(release_link)

                quality = get_qual(release_link)
                if not quality:
                    quality = 'sd'

            else:
                quality = 'sd'
        info = []
        #if '3d' in fmt or '.3D.' in release_name: info.append('3D')
        #if any(i in ['hevc', 'h265', 'h.265', 'x265'] for i in fmt): info.append('HEVC')

        return quality, info
    except:
        return 'sd', []



def getFileType(url):
    try:
        url = six.ensure_str(url)
        url = client.replaceHTMLCodes(url)
        url = unquote(url)
        url = url.lower()
        url = re.sub('[^a-z0-9 ]+', ' ', url)
    except:
        url = str(url)

    file_type = []

    # Video quality
    if any(term in url for term in [' bluray ', ' blu ray ']):
        file_type.append('BLURAY')
    if any(term in url for term in [' bd r ', ' bdr ', ' bd rip ', ' bdrip ', ' br rip ', ' brrip ']):
        file_type.append('BD-RIP')
    if ' remux ' in url:
        file_type.append('REMUX')
    if any(term in url for term in [' dvdrip ', ' dvd rip ']):
        file_type.append('DVD-RIP')
    if any(term in url for term in [' dvd ', ' dvdr ', ' dvd r ']):
        file_type.append('DVD')
    if any(term in url for term in [' webdl ', ' web dl ', ' web ', ' web rip ', ' webrip ']):
        file_type.append('WEB')
    if ' hdtv ' in url:
        file_type.append('HDTV')
    if ' sdtv ' in url:
        file_type.append('SDTV')
    if any(term in url for term in [' hdrip ', ' hd rip ']):
        file_type.append('HDRIP')
    if any(term in url for term in [' uhdrip ', ' uhd rip ']):
        file_type.append('UHDRIP')
    if ' r5 ' in url:
        file_type.append('R5')
    if any(term in url for term in [' cam ', ' hdcam ', ' hd cam ', ' cam rip ', ' camrip ']):
        file_type.append('CAM')
    if any(term in url for term in [' ts ', ' telesync ', ' hdts ', ' pdvd ']):
        file_type.append('TS')
    if any(term in url for term in [' tc ', ' telecine ', ' hdtc ']):
        file_type.append('TC')
    if any(term in url for term in [' scr ', ' screener ', ' dvdscr ', ' dvd scr ']):
        file_type.append('SCR')

    # Video codecs
    if ' xvid ' in url:
        file_type.append('XVID')
    if ' avi ' in url:
        file_type.append('AVI')
    if any(term in url for term in [' h 264 ', ' h264 ', ' x264 ', ' avc ']):
        file_type.append('H.264')
    if any(term in url for term in [' h 265 ', ' h256 ', ' x265 ', ' hevc ']):
        file_type.append('HEVC')
    if ' hi10p ' in url:
        file_type.append('HI10P')
    if ' 10bit ' in url:
        file_type.append('10BIT')
    if ' 3d ' in url:
        file_type.append('3D')
    if any(term in url for term in [' hdr ', ' hdr10 ', ' dolby vision ', ' hlg ']):
        file_type.append('HDR')
    if ' imax ' in url:
        file_type.append('IMAX')

    # Audio codecs
    if any(term in url for term in [' ac3 ', ' ac 3 ']):
        file_type.append('AC3')
    if ' aac ' in url:
        file_type.append('AAC')
    if ' aac5 1 ' in url:
        file_type.append('AAC / 5.1')
    if any(term in url for term in [' dd ', ' dolby ', ' dolbydigital ', ' dolby digital ']):
        file_type.append('DD')
    if any(term in url for term in [' truehd ', ' true hd ']):
        file_type.append('TRUEHD')
    if ' atmos ' in url:
        file_type.append('ATMOS')
    if any(term in url for term in [' ddplus ', ' dd plus ', ' ddp ', ' eac3 ', ' eac 3 ']):
        file_type.append('DD+')
    if ' dts ' in url:
        file_type.append('DTS')
    if any(term in url for term in [' hdma ', ' hd ma ']):
        file_type.append('HD.MA')
    if any(term in url for term in [' hdhra ', ' hd hra ']):
        file_type.append('HD.HRA')
    if any(term in url for term in [' dtsx ', ' dts x ']):
        file_type.append('DTS:X')
    if ' dd5 1 ' in url:
        file_type.append('DD / 5.1')
    if ' ddp5 1 ' in url:
        file_type.append('DD+ / 5.1')
    if any(term in url for term in [' 5 1 ', ' 6ch ']):
        file_type.append('5.1')
    if any(term in url for term in [' 7 1 ', ' 8ch ']):
        file_type.append('7.1')

    # Subtitles and dubbing
    if ' korsub ' in url:
        file_type.append('HC-SUBS')
    if any(term in url for term in [' subs ', ' subbed ', ' sub ']):
        file_type.append('SUBS')
    if any(term in url for term in [' dub ', ' dubbed ', ' dublado ']):
        file_type.append('DUB')

    # Other tags
    if ' repack ' in url:
        file_type.append('REPACK')
    if ' proper ' in url:
        file_type.append('PROPER')
    if ' nuked ' in url:
        file_type.append('NUKED')

    return ' / '.join(file_type)



def getFileType_old(url):

    try:
        url = six.ensure_str(url)
        url = client.replaceHTMLCodes(url)
        url = unquote(url)
        url = url.lower()
        url = re.sub('[^a-z0-9 ]+', ' ', url)
    except:
        url = str(url)
    type = ''

    if any(i in url for i in [' bluray ', ' blu ray ']):
        type += ' BLURAY /'
    if any(i in url for i in [' bd r ', ' bdr ', ' bd rip ', ' bdrip ', ' br rip ', ' brrip ']):
        type += ' BD-RIP /'
    if ' remux ' in url:
        type += ' REMUX /'
    if any(i in url for i in [' dvdrip ', ' dvd rip ']):
        type += ' DVD-RIP /'
    if any(i in url for i in [' dvd ', ' dvdr ', ' dvd r ']):
        type += ' DVD /'
    if any(i in url for i in [' webdl ', ' web dl ', ' web ', ' web rip ', ' webrip ']):
        type += ' WEB /'
    if ' hdtv ' in url:
        type += ' HDTV /'
    if ' sdtv ' in url:
        type += ' SDTV /'
    if any(i in url for i in [' hdrip ', ' hd rip ']):
        type += ' HDRIP /'
    if any(i in url for i in [' uhdrip ', ' uhd rip ']):
        type += ' UHDRIP /'
    if ' r5 ' in url:
        type += ' R5 /'
    if any(i in url for i in [' cam ', ' hdcam ', ' hd cam ', ' cam rip ', ' camrip ']):
        type += ' CAM /'
    if any(i in url for i in [' ts ', ' telesync ', ' hdts ', ' pdvd ']):
        type += ' TS /'
    if any(i in url for i in [' tc ', ' telecine ', ' hdtc ']):
        type += ' TC /'
    if any(i in url for i in [' scr ', ' screener ', ' dvdscr ', ' dvd scr ']):
        type += ' SCR /'
    if ' xvid ' in url:
        type += ' XVID /'
    if ' avi' in url:
        type += ' AVI /'
    if any(i in url for i in [' h 264 ', ' h264 ', ' x264 ', ' avc ']):
        type += ' H.264 /'
    if any(i in url for i in [' h 265 ', ' h256 ', ' x265 ', ' hevc ']):
        type += ' HEVC /'
    if ' hi10p ' in url:
        type += ' HI10P /'
    if ' 10bit ' in url:
        type += ' 10BIT /'
    if ' 3d ' in url:
        type += ' 3D /'
    if any(i in url for i in [' hdr ', ' hdr10 ', ' dolby vision ', ' hlg ']):
        type += ' HDR /'
    if ' imax ' in url:
        type += ' IMAX /'
    if any(i in url for i in [' ac3 ', ' ac 3 ']):
        type += ' AC3 /'
    if ' aac ' in url:
        type += ' AAC /'
    if ' aac5 1 ' in url:
        type += ' AAC / 5.1 /'
    if any(i in url for i in [' dd ', ' dolby ', ' dolbydigital ', ' dolby digital ']):
        type += ' DD /'
    if any(i in url for i in [' truehd ', ' true hd ']):
        type += ' TRUEHD /'
    if ' atmos ' in url:
        type += ' ATMOS /'
    if any(i in url for i in [' ddplus ', ' dd plus ', ' ddp ', ' eac3 ', ' eac 3 ']):
        type += ' DD+ /'
    if ' dts ' in url:
        type += ' DTS /'
    if any(i in url for i in [' hdma ', ' hd ma ']):
        type += ' HD.MA /'
    if any(i in url for i in [' hdhra ', ' hd hra ']):
        type += ' HD.HRA /'
    if any(i in url for i in [' dtsx ', ' dts x ']):
        type += ' DTS:X /'
    if ' dd5 1 ' in url:
        type += ' DD / 5.1 /'
    if ' ddp5 1 ' in url:
        type += ' DD+ / 5.1 /'
    if any(i in url for i in [' 5 1 ', ' 6ch ']):
        type += ' 5.1 /'
    if any(i in url for i in [' 7 1 ', ' 8ch ']):
        type += ' 7.1 /'
    if ' korsub ' in url:
        type += ' HC-SUBS /'
    if any(i in url for i in [' subs ', ' subbed ', ' sub ']):
        type += ' SUBS /'
    if any(i in url for i in [' dub ', ' dubbed ', ' dublado ']):
        type += ' DUB /'
    if ' repack ' in url:
        type += ' REPACK /'
    if ' proper ' in url:
        type += ' PROPER /'
    if ' nuked ' in url:
        type += ' NUKED /'
    type = type.rstrip('/')
    return type

def check_sd_url(release_link):
    try:
        release_link = re.sub('[^A-Za-z0-9]+', ' ', release_link)
        release_link = release_link.lower()
        try: release_link = six.ensure_str(release_link)
        except: pass
        quality = get_qual(release_link)
        if not quality:
            quality = 'sd'
        return quality
    except:
        return 'sd'


def check_direct_url(url):
    try:
        url = re.sub('[^A-Za-z0-9]+', ' ', url)
        url = six.ensure_str(url)
        url = url.lower()
        quality = get_qual(url)
        if not quality:
            quality = 'sd'
        return quality
    except:
        return 'sd'

def check_url(url):
    try:
        url = client.replaceHTMLCodes(url)
        url = unquote(url)
        url = re.sub('[^A-Za-z0-9]+', ' ', url)
        url = six.ensure_str(url)
        url = url.lower()
    except:
        url = str(url)

    try:
        quality = get_qual(url)
        if not quality:
            quality = 'sd'
        return quality
    except:
        return 'sd'

def label_to_quality(label):
    try:
        try: label = int(re.search('(\d+)', label).group(1))
        except: label = 0

        if label >= 2160:
            return '4K'
        elif label >= 1080:
            return '1080p'
        elif 720 <= label < 1080:
            return '720p'
        elif label < 720:
            return 'sd'
    except:
        return 'sd'

def strip_domain(url):
    try:
        url = six.ensure_str(url)
        if url.lower().startswith('http') or url.startswith('/'):
            url = re.findall('(?://.+?|)(/.+)', url)[0]
        url = client.replaceHTMLCodes(url)
        return url
    except:
        return


def is_host_valid(url, domains):
    try:
        url = six.ensure_str(url).lower()
        if any(x in url for x in ['.rar.', '.zip.', '.iso.']) or any(url.endswith(x) for x in ['.rar', '.zip', '.idx', '.sub', '.srt']):
            return False, ''
        if any(x in url for x in ['sample', 'trailer', 'zippyshare', 'facebook', 'youtu']):
            return False, ''
        host = __top_domain(url)
        hosts = [domain.lower() for domain in domains if host and host in domain.lower()]

        if hosts and '.' not in host:
            host = hosts[0]
        if hosts and any([h for h in ['google', 'picasa', 'blogspot'] if h in host]):
            host = 'gvideo'
        if hosts and any([h for h in ['akamaized','ocloud'] if h in host]):
            host = 'CDN'
        return any(hosts), host
    except:
        return False, ''


def __top_domain(url):
    if not (url.startswith('//') or url.startswith('http://') or url.startswith('https://')):
        url = '//' + url
    elements = urlparse(url)
    domain = elements.netloc or elements.path
    domain = domain.split('@')[-1].split(':')[0]
    regex = "(?:www\.)?([\w\-]*\.[\w\-]{2,3}(?:\.[\w\-]{2,3})?)$"
    res = re.search(regex, domain)
    if res: domain = res.group(1)
    domain = domain.lower()
    return domain

def aliases_to_array(aliases, filter=None):
    try:
        if not filter:
            filter = []
        if isinstance(filter, six.string_types):
            filter = [filter]

        return [x.get('title') for x in aliases if not filter or x.get('country') in filter]
    except:
        return []


def append_headers(headers):
    return '|%s' % '&'.join(['%s=%s' % (key, quote_plus(headers[key])) for key in headers])


def _size(siz):
    if siz in ['0', 0, '', None]: return 0.0, ''
    div = 1 if siz.lower().endswith(('gb', 'gib')) else 1024
    float_size = float(re.sub('[^0-9|/.|/,]', '', siz.replace(',', '.'))) / div
    str_size = str('%.2f GB' % float_size)
    return float_size, str_size


def get_size(url):
    try:
        size = client.request(url, output='file_size')
        if size == '0': size = False
        size = convert_size(size)
        return size
    except: return False


def convert_size(size_bytes):
    import math
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    if size_name[i] == 'B' or size_name[i] == 'KB': return None
    return "%s %s" % (s, size_name[i])


def check_directstreams(url, hoster='', quality='SD'):
    urls = []
    host = hoster

    if 'google' in url or any(x in url for x in ['youtube.', 'docid=']):
        urls = directstream.google(url)
        if not urls:
            tag = directstream.googletag(url)
            if tag:
                urls = [{'quality': tag[0]['quality'], 'url': url}]
        if urls:
            host = 'gvideo'
    elif 'ok.ru' in url:
        urls = directstream.odnoklassniki(url)
        if urls:
            host = 'vk'
    elif 'vk.com' in url:
        urls = directstream.vk(url)
        if urls:
            host = 'vk'
    elif any(x in url for x in ['akamaized', 'blogspot', 'ocloud.stream']):
        urls = [{'url': url}]
        if urls:
            host = 'CDN'

    direct = bool(urls)

    if not urls:
        urls = [{'quality': quality, 'url': url}]

    return urls, host, direct

def scraper_error(name):
    c.log('An exception error in scraper "' + name + '" occurred.')


# if salt is provided, it should be string
# ciphertext is base64 and passphrase is string
def evp_decode(cipher_text, passphrase, salt=None):
    cipher_text = base64.b64decode(cipher_text)
    if not salt:
        salt = cipher_text[8:16]
        cipher_text = cipher_text[16:]
    data = evpKDF(passphrase, salt)
    decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(data['key'], data['iv']))
    plain_text = decrypter.feed(cipher_text)
    plain_text += decrypter.feed()
    return plain_text


def evpKDF(passwd, salt, key_size=8, iv_size=4, iterations=1, hash_algorithm="md5"):
    target_key_size = key_size + iv_size
    #cm - added the 'b' to the byte string - 20250613
    derived_bytes = b""
    number_of_derived_words = 0
    block = None
    hasher = hashlib.new(hash_algorithm)
    while number_of_derived_words < target_key_size:
        if block is not None:
            hasher.update(block)

        hasher.update(passwd)
        hasher.update(salt)
        block = hasher.digest()
        hasher = hashlib.new(hash_algorithm)

        for _i in list(range(1, iterations)):
            hasher.update(block)
            block = hasher.digest()
            hasher = hashlib.new(hash_algorithm)

        derived_bytes += block[0: min(len(block), (target_key_size - number_of_derived_words) * 4)]

        number_of_derived_words += len(block) / 4

    return {
        "key": derived_bytes[0: key_size * 4],
        "iv": derived_bytes[key_size * 4:]
    }
